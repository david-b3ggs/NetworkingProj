package topic.app.client;

import topic.serialization.Query;
import topic.serialization.Response;
import topic.serialization.TopicException;

import java.io.InterruptedIOException;
import java.net.DatagramSocket;
import java.net.DatagramPacket;
import java.net.InetAddress;
import java.io.IOException;

import static java.lang.System.exit;

public class Client {

    private static final int TIMEOUT = 3000;   // Resend timeout (milliseconds)
    private static final int MAXTRIES = 5;     // Maximum retransmissions

    public static void main(String[] args) throws IOException {

        if (args.length != 3) { // Test for correct # of args
            throw new IllegalArgumentException("Parameter(s): <Server> <Port> <Requested Number of Responses>");
        }

        String serverString = args[0];
        Integer portNum = Integer.parseInt(args[1]);
        Integer responseNum = Integer.parseInt(args[2]);

        if (portNum < 1024 || portNum > 65535){
            System.err.println("INCORRECT PORT NUMBER ARGUMENT");
            exit(-1);
        }

        if (responseNum < 0 || responseNum > 65535){
            System.err.println("INCORRECT RESPONSE NUMBER ARGUMENT");
            exit(-1);
        }

        InetAddress addr = InetAddress.getByName(serverString);

        DatagramSocket socket = new DatagramSocket();

        socket.setSoTimeout(TIMEOUT);

        long leftLimit = 1L;
        long rightLimit = 4294967295L;
        long generatedID = leftLimit + (long) (Math.random() * (rightLimit - leftLimit));

        Query sender = new Query(generatedID, responseNum);

        byte [] encoded = sender.encode();
        byte [] received = new byte [65535];
        DatagramPacket sendPacket = new DatagramPacket(encoded, encoded.length, addr, portNum);
        DatagramPacket receivePacket = new DatagramPacket(received, 65535, addr, portNum);

        int tries = 0;      // Packets may be lost, so we have to keep trying
        boolean receivedResponse = false;
        Response response = null;

        do {
            socket.send(sendPacket);

            try {
                socket.receive(receivePacket);
                //check recieve address, error code, response format, and queryID
                if (!receivePacket.getAddress().equals(addr)){
                    System.err.println("INCORRECT RESPONSE ORIGIN");
                    exit(-1);
                }

                try{
                     response = new Response(receivePacket.getData());
                } catch (TopicException e){
                    System.err.println(e.getErrorCode().getErrorMessage());
                    exit(-1);
                }
                receivedResponse = true;

                //validate fields(qid, errorcode
                if (response.getQueryID() != generatedID){
                    receivedResponse = false;
                    tries++;
                }
                else {

                    if (response.getErrorCode().getErrorCodeValue() != 1){
                        System.err.println(response.getErrorCode().getErrorMessage());
                        exit(-1);
                    }
                }

            } catch (InterruptedIOException e){
                tries++;
            }
        } while ((!receivedResponse) && (tries < MAXTRIES));

        if (receivedResponse){
            System.out.println(response.toString());
        }
        else {
            System.out.println("TIME OUT, COULD NOT RECEIVE RESPONSE");
        }

        socket.close();
    }
}