package tiktak.serialization;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Objects;

public class ID extends Message {

    String id = null;

    public ID(String s){
        super();
        this.id = s;
    }

    public String getID(){
        return this.id;
    }

    public ID setId(String id)throws ValidationException{

        if (id == null){
            throw new ValidationException("Nonce format error");
        }

        if (!id.isEmpty() && !id.isBlank() && id.matches("(ID [0-9a-zA-Z]*)") ){
            this.id = id;
            return this;
        }
        else {
            throw new ValidationException("Nonce format error");
        }
    }

    @Override
    public String toString() {
        return "ID: id=" + this.id;
    }

    @Override
    public void encode(MessageOutput out) throws IOException {
        if (out == null){
            throw new NullPointerException("MESSAGE OUTPUT NULL EXCEPTION");
        }
        else if (out.getOut() == null){
            throw new IOException("Message Output Null Exception");
        }

        String returnString = "ID " + this.id + "\r\n";
        out.getOut().write(returnString.getBytes(StandardCharsets.ISO_8859_1));
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ID id1 = (ID) o;
        return Objects.equals(id, id1.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }
}
