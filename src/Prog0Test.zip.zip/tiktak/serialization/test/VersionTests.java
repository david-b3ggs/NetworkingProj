package tiktak.serialization.test;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import tiktak.serialization.main.Challenge;
import tiktak.serialization.main.MessageOutput;
import tiktak.serialization.main.Version;

import java.io.FileOutputStream;
import java.io.IOException;

@DisplayName("Version Tests")
public class VersionTests {

    Version version = new Version();

    @Test
    void testToString(){
        Assertions.assertEquals("TIKTAK 1.0\r\n", version.toString());
    }

    @Nested
    @DisplayName("EncodeTests")
    class EncodeTests{

        Challenge challenge = new Challenge();

        @Test
        void testEncodeThrowsNull(){
            Assertions.assertThrows(NullPointerException.class, () ->
                    challenge.encode(new MessageOutput(null)));
        }

        @Test
        void testDecodeThrowsIO(){
            Assertions.assertThrows(IOException.class, () ->
                    challenge.encode(new MessageOutput(new FileOutputStream("NOT REAL"))));
        }
    }

}