package tiktak.serialization.test;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import tiktak.serialization.main.Challenge;
import tiktak.serialization.main.MessageOutput;
import tiktak.serialization.main.ValidationException;

import java.io.FileOutputStream;
import java.io.IOException;

@DisplayName("Challenge Tests")
public class ChallengeTests {

    Challenge challenge = new Challenge();

    //TODO: Test encoding
    @Test
    void testGetNonce(){
        challenge.setNonce("123");

        Assertions.assertEquals("123", challenge.getNonce());
    }

    @Test
    void testSetNonceValid(){
        Assertions.assertDoesNotThrow(() -> challenge.setNonce("123"));
    }

    @Test
    void testSetNonce1(){
        Assertions.assertThrows(ValidationException.class, () ->challenge.setNonce("q234"));
    }

    @Test
    void testSetNonce2(){
        Assertions.assertThrows(ValidationException.class, () ->challenge.setNonce("fds"));
    }

    @Test
    void testSetNonce3(){
        Assertions.assertThrows(ValidationException.class, () ->challenge.setNonce(""));
    }

    @Nested
    @DisplayName("EncodeTests")
    class EncodeTests{

        Challenge challenge = new Challenge();

        @Test
        void testEncodeThrowsNull(){
            Assertions.assertThrows(NullPointerException.class, () ->
                    challenge.encode(new MessageOutput(null)));
        }

        @Test
        void testDecodeThrowsIO(){
            Assertions.assertThrows(IOException.class, () ->
                    challenge.encode(new MessageOutput(new FileOutputStream("NOT REAL"))));
        }
    }


}
