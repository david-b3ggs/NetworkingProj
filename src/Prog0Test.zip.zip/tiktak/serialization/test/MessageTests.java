package tiktak.serialization.test;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Assertions;
import tiktak.serialization.main.*;

import java.io.*;

@DisplayName("All Message Tests")
public class MessageTests {


    @Nested
    @DisplayName("Decode Tests")
    class DecodeTests{

        @Test
        void testMessageDecodeNullException(){
            Assertions.assertThrows(NullPointerException.class, () -> Message.decode(null));
        }

        @Test
        void testMessageDecodeValidException(){
            String input = "notgood";
            InputStream in = new ByteArrayInputStream(input.getBytes());
            Assertions.assertThrows(ValidationException.class, () -> Message.decode(new MessageInput(in)));
        }

        @Test
        void testMessageDecodeIOException(){
            Assertions.assertThrows(IOException.class, () -> Message.decode(new MessageInput(new FileInputStream("badio"))));
        }

        @Test
        void testDecodeBadMessageStart(){
            String input = " ID %\r\n";
            InputStream in = new ByteArrayInputStream(input.getBytes());

            Assertions.assertThrows(ValidationException.class, () -> Message.decode(new MessageInput(in)));
        }

        //BEGIN TESTING ID DECODE
        @Test
        void testDecodeReturnID(){
            String input = "ID a\r\n";
            InputStream in = new ByteArrayInputStream(input.getBytes());

            Assertions.assertEquals(ID.class, Message.decode(new MessageInput(in)));
        }

        @Test
        void testDecodeEmptyID(){
            String input = "ID \r\n";
            InputStream in = new ByteArrayInputStream(input.getBytes());

            Assertions.assertThrows(ValidationException.class, () -> Message.decode(new MessageInput(in)));
        }

        @Test
        void testDecodeBadGrammer(){
            String input = " ID a\r\n";
            InputStream in = new ByteArrayInputStream(input.getBytes());

            Assertions.assertThrows(ValidationException.class, () -> Message.decode(new MessageInput(in)));
        }

        @Test
        void testDecodeNonAlphNumeric1(){
            String input = "ID %\r\n";
            InputStream in = new ByteArrayInputStream(input.getBytes());

            Assertions.assertThrows(ValidationException.class, () -> Message.decode(new MessageInput(in)));
        }

        @Test
        void testDecodeNonAlphNumeric2(){
            String input = "ID a12)\r\n";
            InputStream in = new ByteArrayInputStream(input.getBytes());

            Assertions.assertThrows(ValidationException.class, () -> Message.decode(new MessageInput(in)));
        }

        @Test
        void testDecodeBadMessageStartID(){
            String input = "iD a12)\r\n";
            InputStream in = new ByteArrayInputStream(input.getBytes());

            Assertions.assertThrows(ValidationException.class, () -> Message.decode(new MessageInput(in)));
        }

        //BEGIN TESTING VERSION DECODE
        @Test
        void testDecodeReturnVersion(){
            String input = "TIKTAK 1.0\r\n";
            InputStream in = new ByteArrayInputStream(input.getBytes());

            Assertions.assertEquals(Version.class, Message.decode(new MessageInput(in)));
        }

        @Test
        void testDecodeVersionIncorrect1(){
            String input = "TIKTAK 1\r\n";
            InputStream in = new ByteArrayInputStream(input.getBytes());

            Assertions.assertThrows(ValidationException.class, () ->Message.decode(new MessageInput(in)));
        }

        @Test
        void testDecodeVersionIncorrect2(){
            String input = "TIKTAK 10\r\n";
            InputStream in = new ByteArrayInputStream(input.getBytes());

            Assertions.assertThrows(ValidationException.class, () ->Message.decode(new MessageInput(in)));
        }

        @Test
        void testDecodeBadMessageStartVersion(){
            String input = "TikTak 1.0\r\n";
            InputStream in = new ByteArrayInputStream(input.getBytes());

            Assertions.assertThrows(ValidationException.class, () -> Message.decode(new MessageInput(in)));
        }

        @Test
        void testDecodeReturnChallenge(){
            String input = "CLNG a\r\n";
            InputStream in = new ByteArrayInputStream(input.getBytes());

            Assertions.assertEquals(Challenge.class, Message.decode(new MessageInput(in)));
        }

        @Test
        void testDecodeBadServ1(){
            String input = "CLNG %\r\n";
            InputStream in = new ByteArrayInputStream(input.getBytes());

            Assertions.assertThrows(ValidationException.class, () -> Message.decode(new MessageInput(in)));
        }

        @Test
        void testDecodeBadServ2(){
            String input = "CLNG \r\n";
            InputStream in = new ByteArrayInputStream(input.getBytes());

            Assertions.assertThrows(ValidationException.class, () -> Message.decode(new MessageInput(in)));
        }

        @Test
        void testDecodeChallengeMessageError(){
            String input = "NG 123\r\n";
            InputStream in = new ByteArrayInputStream(input.getBytes());

            Assertions.assertThrows(ValidationException.class, () -> Message.decode(new MessageInput(in)));
        }
    }

    @Test
    void testGetOperationValidTIK(){
        Message id = new Version();
        Assertions.assertEquals("VERSION", id.getOperation());
    }

    @Test
    void testGetOperationValidID(){
        Message id = new ID();
        Assertions.assertEquals("ID", id.getOperation());
    }

    @Test
    void testGetOperationValidChallenge(){
        Message id = new Challenge();
        Assertions.assertEquals("CHALLENGE", id.getOperation());
    }
}
