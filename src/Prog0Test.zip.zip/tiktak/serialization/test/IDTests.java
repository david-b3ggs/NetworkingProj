package tiktak.serialization.test;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import tiktak.serialization.main.Challenge;
import tiktak.serialization.main.ID;
import tiktak.serialization.main.MessageOutput;
import tiktak.serialization.main.ValidationException;

import java.io.FileOutputStream;
import java.io.IOException;

@DisplayName("All IDTests")
public class IDTests {

    //TODO: Test encode
    private ID id = new ID();

    @Test
    void testSetIDValid(){
        Assertions.assertDoesNotThrow(() -> id.setId("1a"));
    }

    @Test
    void testSetIDNonAlphNumeric1(){
        String testID = "%Hi[";

        Assertions.assertThrows(ValidationException.class, () -> id.setId(testID));
    }

    @Test
    void testSetIDNonAlphNumeric2(){
        String testID = "asdfsdlfdsaljk1231u9$";

        Assertions.assertThrows(ValidationException.class, () -> id.setId(testID));
    }

    @Test
    void testSetIDNonAlphNumeric3(){
        String testID = "asdfsdlfd/saljk1231u9";

        Assertions.assertThrows(ValidationException.class, () -> id.setId(testID));
    }

    @Test
    void testSetIDBlank(){
        String testID = " ";

        Assertions.assertThrows(ValidationException.class, () -> id.setId(testID));
    }

    @Test
    void testGetID(){
        String test = "testid4";
        id.setId(test);

        Assertions.assertEquals("testid4", id.getID());
    }

    @Nested
    @DisplayName("EncodeTests")
    class EncodeTests{

        Challenge challenge = new Challenge();

        @Test
        void testEncodeThrowsNull(){
            Assertions.assertThrows(NullPointerException.class, () ->
                    challenge.encode(new MessageOutput(null)));
        }

        @Test
        void testDecodeThrowsIO(){
            Assertions.assertThrows(IOException.class, () ->
                    challenge.encode(new MessageOutput(new FileOutputStream("NOT REAL"))));
        }
    }

}
