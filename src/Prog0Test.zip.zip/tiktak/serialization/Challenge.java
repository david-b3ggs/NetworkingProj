package tiktak.serialization.main;

public class Challenge extends Message {

    public String getNonce(){
        return null;
    }

    public Challenge setNonce(String nonce){
        return null;
    }


    @Override
    public void encode(MessageOutput out) {

    }
}
