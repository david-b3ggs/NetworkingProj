package tiktak.serialization.main;

public class Version extends Message {

    private final String version = "1.0";

    @Override
    public String toString() {
        return "TIKTAK " + version + "\r\n";
    }

    @Override
    public void encode(MessageOutput out) {

    }
}
