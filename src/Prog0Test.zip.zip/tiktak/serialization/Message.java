package tiktak.serialization.main;

public abstract class Message {

    public static Message decode(MessageInput in){
        return null;
    }

    public abstract void encode(MessageOutput out);

    public String getOperation(){
        String out = this.getClass().getName().toUpperCase();
        String[] array = out.split("[.]");
        return array[array.length - 1];
    }

}
