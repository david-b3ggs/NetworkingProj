package tiktak.serialization.main;

import java.io.InputStream;

public class MessageInput {

    public MessageInput(InputStream in){

    }
}
