package tiktak.serialization.main;

public class ValidationException extends Exception {
}
