package tiktak.serialization.main;

import java.io.OutputStream;

public class MessageOutput {

    public MessageOutput(OutputStream out){

    }
}
