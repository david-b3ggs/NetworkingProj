package tiktak.serialization.main;

public class ID extends Message {

    String id = null;

    public String getID(){
        return this.id;
    }

    public ID setId(String id){
        this.id = id;
        return this;
    }

    @Override
    public String toString() {
        return "ID " + this.id + "\r\n";
    }

    @Override
    public void encode(MessageOutput out) {

    }
}
