package tiktak.serialization.test;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

@DisplayName("LTSRL Tests")
public class LtsrlTests {

    @Test
    void testConstructor1(){

    }

    @Test
    void testConstructor2(){

    }

    @Test
    void testConstructor3(){

    }

    @Test
    void testConstructor4(){

    }

    @Test
    void testToString(){

    }
}
